from django.apps import AppConfig


class UsermanagementappConfig(AppConfig):
    name = 'userManagementApp'
