from django.shortcuts import render_to_response


def main(request):
    return render_to_response("index.html")


def works(request):
    return render_to_response("works.html")

def learn(request):
    return render_to_response("learn.html")
